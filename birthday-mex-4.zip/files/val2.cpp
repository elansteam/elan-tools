#include "testlib.h"

using namespace std;

int main(int argc, char* argv[]) {
    registerValidation(argc, argv);

    int n = inf.readInt(1, 2e5, "n");
    inf.readEoln();

    set<int> numbers;

    for (int i = 1; i <= n - 1; ++i) {
        int num = inf.readInt(1, 2e5, "num[" + to_string(i) + "]");
        if (i != n - 1) inf.readSpace();
        ensuref(numbers.find(num) == numbers.end(), "Numbers must not repeat");
        numbers.insert(num);
    }

    inf.readEoln();
    inf.readEof();

    return 0;
}
