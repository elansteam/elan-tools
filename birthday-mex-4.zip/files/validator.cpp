#include "testlib.h"

using namespace std;

int main() {
    registerValidation();

    int n = inf.readInt(1, 2e5, "n");
    inf.readEoln();

    set<int> numbers;

    for (int i = 1; i <= n - 1; ++i) {
        int num = inf.readInt(2, 2e5, "num[" + to_string(i) + "]");
        inf.readSpace();

        ensure(numbers.find(num) == numbers.end(), "Numbers must not repeat");
        numbers.insert(num);
    }

    inf.readEoln();
    inf.readEof();

    return 0;
}

