n = int(input())
x = map(int, input().split())
s = n * (n + 1) // 2
print(s - sum(x))
